from django.apps import AppConfig


class BygenreConfig(AppConfig):
    name = 'bygenre'
