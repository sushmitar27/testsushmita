from django.urls import path
from . import views

urlpatterns = [
    path('',views.MainByGenreView, name = 'bygenre'),
    path('action/',views.ActionPopularMoviewsView, name = 'action'),
    path('adventure/',views.AdventurePopularMoviewsView, name = 'adventure'),
    path('animation/',views.AnimationPopularMoviewsView, name = 'animation'),
    path('comedy/',views.ComedyPopularMoviewsView, name = 'comedy'),
    path('crime/',views.CrimePopularMoviewsView, name = 'crime'),
    path('documentary/',views.DocumentaryPopularMoviewsView, name = 'documentary'),
    path('drama/',views.DramaPopularMoviewsView, name = 'drama'),
    path('family/',views.FamilyPopularMoviewsView, name = 'family'),
    path('fantasy/',views.FantasyPopularMoviewsView, name = 'fantasy'),
    path('foreign/',views.ForeignPopularMoviewsView, name = 'foreign'),
    path('history/',views.HistoryPopularMoviewsView, name = 'history'),
    path('horror/',views.HorrorPopularMoviewsView, name = 'horror'),
    path('music/',views.MusicPopularMoviewsView, name = 'music'),
    path('mystery/',views.MysteryPopularMoviewsView, name = 'mystery'),
    path('romance/',views.RomancePopularMoviewsView, name = 'romance'),
    path('sciencefiction/',views.ScienceFictionPopularMoviewsView, name = 'sciencefiction'),
    path('thriller/',views.ThrillerPopularMoviewsView, name = 'thriller'),
    path('tvmovie/',views.TVMoviePopularMoviewsView, name = 'tvmovie'),
    path('war/',views.WarPopularMoviewsView, name = 'war'),
    path('western/',views.WesternPopularMoviewsView, name = 'western'),
]
