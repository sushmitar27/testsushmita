from django.views.generic import ListView
from django.views.generic import DetailView
from django.views.generic import TemplateView
from .models import Notification

# Create your views here.
class NotificationListView(ListView):
    model = Notification
    template_name = 'home.html'

class NotificationDetailView(DetailView):
    model = Notification
    template_name = 'details.html'
    context_object_name = 'notify'

class AboutPageView(TemplateView):
    template_name = 'about.html'

class ContactPageView(TemplateView):
    template_name = 'contact.html'
