#%matplotlib inline

#from IPython.display import Image, HTML
import json
import datetime
import ast
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from scipy import stats
from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier, XGBRegressor
from wordcloud import WordCloud, STOPWORDS
import plotly
import plotly.offline as py
#py.init_notebook_mode(connected=True)
import plotly.graph_objs as go
import plotly.tools as tls
import warnings
warnings.filterwarnings('ignore')
#plotly.tools.set_credentials_file(username='rounakbanik', api_key='xTLaHBy9MVv5szF4Pwan')

sns.set_style('whitegrid')
sns.set(font_scale=1.25)
pd.set_option('display.max_colwidth', 50)

df = pd.read_csv('C:/MSc/Project/input/movies_metadata.csv')
print(df.head().transpose())

print(df.columns)

# Gives the total number of rows
total_rows=len(df.axes[0])
print(total_rows)

# Gives the total number of columns
total_cols=len(df.axes[1])
print(total_cols)

print(df.shape)

print(df.info())

df = df.drop(['imdb_id'], axis=1)

print(df[df['original_title'] != df['title']][['title', 'original_title']].head())

df = df.drop('original_title', axis=1)

print(df[df['revenue'] == 0].shape)

df['revenue'] = df['revenue'].replace(0, np.nan)

df['budget'] = pd.to_numeric(df['budget'], errors='coerce')
df['budget'] = df['budget'].replace(0, np.nan)
print(df[df['budget'].isnull()].shape)

print("Displaying Return:-")
df['return'] = df['revenue'] / df['budget']
print(df[df['return'].isnull()].shape)

print("Displaying adult fields values:-")
df['year'] = pd.to_datetime(df['release_date'], errors='coerce').apply(lambda x: str(x).split('-')[0] if x != np.nan else np.nan)
print(df['adult'].value_counts())

print("Display adult")
df = df.drop('adult', axis=1)

base_poster_url = 'http://image.tmdb.org/t/p/w185/'
df['poster_path'] = "<img src='" + base_poster_url + df['poster_path'] + "' style='height:100px;'>"

#Title and Overview Wordcloud

#df['title'] = df['title'].astype('str')
#df['overview'] = df['overview'].astype('str')

#title_corpus = ' '.join(df['title'])
#overview_corpus = ' '.join(df['overview'])

#title_wordcloud = WordCloud(stopwords=STOPWORDS, background_color='white', height=2000, width=4000).generate(title_corpus)
#plt.figure(figsize=(16,8))
#plt.imshow(title_wordcloud)
#plt.axis('off')
#plt.show()

#overview_wordcloud = WordCloud(stopwords=STOPWORDS, background_color='white', height=2000, width=4000).generate(overview_corpus)
#plt.figure(figsize=(16,8))
#plt.imshow(overview_wordcloud)
#plt.axis('off')
#plt.show()

print("Displaying production countries")
#Production Countries:-
df['production_countries'] = df['production_countries'].fillna('[]').apply(ast.literal_eval)
df['production_countries'] = df['production_countries'].apply(lambda x: [i['name'] for i in x] if isinstance(x, list) else [])
s = df.apply(lambda x: pd.Series(x['production_countries']),axis=1).stack().reset_index(level=1, drop=True)
s.name = 'countries'
con_df = df.drop('production_countries', axis=1).join(s)
con_df = pd.DataFrame(con_df['countries'].value_counts())
con_df['country'] = con_df.index
con_df.columns = ['num_movies', 'country']
con_df = con_df.reset_index().drop('index', axis=1)
print(con_df.head(10))

#con_df = con_df[con_df['country'] != 'United States of America']

#data = [ dict(
#        type = 'choropleth',
#        locations = con_df['country'],
#        locationmode = 'country names',
#        z = con_df['num_movies'],
#        text = con_df['country'],
#        colorscale = [[0,'rgb(255, 255, 255)'],[1,'rgb(255, 0, 0)']],
#        autocolorscale = False,
#        reversescale = False,
#        marker = dict(
#            line = dict (
#                color = 'rgb(180,180,180)',
#                width = 0.5
#            ) ),
#        colorbar = dict(
#            autotick = False,
#            tickprefix = '',
#            title = 'Production Countries'),
#      ) ]

#layout = dict(
#    title = 'Production Countries for the MovieLens Movies (Apart from US)',
#    geo = dict(
#        showframe = False,
#        showcoastlines = False,
#        projection = dict(
#            type = 'Mercator'
#        )
#    )
#)

#fig = dict( data=data, layout=layout )
#py.plot( fig, validate=False, filename='d3-world-map' )

print("Franchise")
#Franchise Movies:-
df_fran = df[df['belongs_to_collection'].notnull()]
df_fran['belongs_to_collection'] = df_fran['belongs_to_collection'].apply(ast.literal_eval).apply(lambda x: x['name'] if isinstance(x, dict) else np.nan)
df_fran = df_fran[df_fran['belongs_to_collection'].notnull()]

fran_pivot = df_fran.pivot_table(index='belongs_to_collection', values='revenue', aggfunc={'revenue': ['mean', 'sum', 'count']}).reset_index()

#Highest Grossing Movie Franchises:-
print(fran_pivot.sort_values('sum', ascending=False).head(10))

#Most Successful Movie Franchises (by Average Gross)
print(fran_pivot.sort_values('mean', ascending=False).head(10))

#Longest Running Franchises
print(fran_pivot.sort_values('count', ascending=False).head(10))

print("Production Companies")
#Production Companies:-
df['production_companies'] = df['production_companies'].fillna('[]').apply(ast.literal_eval)
df['production_companies'] = df['production_companies'].apply(lambda x: [i['name'] for i in x] if isinstance(x, list) else [])

s = df.apply(lambda x: pd.Series(x['production_companies']),axis=1).stack().reset_index(level=1, drop=True)
s.name = 'companies'

com_df = df.drop('production_companies', axis=1).join(s)

com_sum = pd.DataFrame(com_df.groupby('companies')['revenue'].sum().sort_values(ascending=False))
com_sum.columns = ['Total']
com_mean = pd.DataFrame(com_df.groupby('companies')['revenue'].mean().sort_values(ascending=False))
com_mean.columns = ['Average']
com_count = pd.DataFrame(com_df.groupby('companies')['revenue'].count().sort_values(ascending=False))
com_count.columns = ['Number']

com_pivot = pd.concat((com_sum, com_mean, com_count), axis=1)

print(com_pivot)

#Highest Earning Production Companies

print(com_pivot.sort_values('Total', ascending=False).head(10))

#Most Succesful Production Companies

print(com_pivot[com_pivot['Number'] >= 15].sort_values('Average', ascending=False).head(10))

#Original Language:-
print(df['original_language'].drop_duplicates().shape[0])

lang_df = pd.DataFrame(df['original_language'].value_counts())
lang_df['language'] = lang_df.index
lang_df.columns = ['number', 'language']
print(lang_df.head())

#plt.figure(figsize=(12,5))
#sns.barplot(x='language', y='number', data=lang_df.iloc[1:11])
#plt.show()

def clean_numeric(x):
    try:
        return float(x)
    except:
        return np.nan

df['popularity'] = df['popularity'].apply(clean_numeric).astype('float')
df['vote_count'] = df['vote_count'].apply(clean_numeric).astype('float')
df['vote_average'] = df['vote_average'].apply(clean_numeric).astype('float')

print(df['popularity'].describe())

#sns.distplot(df['popularity'].fillna(df['popularity'].median()))
#plt.show()

#df['popularity'].plot(logy=True, kind='hist')
#plt.show()

#Most Popular Movies by Popularity Score
print(df[['title', 'popularity', 'year']].sort_values('popularity', ascending=False).head(10))

print(df['vote_count'].describe())

print(df[['title', 'vote_count', 'year']].sort_values('vote_count', ascending=False).head(10))

df['vote_average'] = df['vote_average'].replace(0, np.nan)
print(df['vote_average'].describe())

#sns.distplot(df['vote_average'].fillna(df['vote_average'].median()))
#plt.show()

print(df[df['vote_count'] > 2000][['title', 'vote_average', 'vote_count' ,'year']].sort_values('vote_average', ascending=False).head(10))

#sns.jointplot(x='vote_average', y='popularity', data=df)
#plt.show()

#sns.jointplot(x='vote_average', y='vote_count', data=df)
#plt.show()

#Movie Release Dates

month_order = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
day_order = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

def get_month(x):
    try:
        return month_order[int(str(x).split('-')[1]) - 1]
    except:
        return np.nan

def get_day(x):
    try:
        year, month, day = (int(i) for i in x.split('-'))    
        answer = datetime.date(year, month, day).weekday()
        return day_order[answer]
    except:
        return np.nan

df['day'] = df['release_date'].apply(get_day)
df['month'] = df['release_date'].apply(get_month)

#plt.figure(figsize=(12,6))
#plt.title("Number of Movies released in a particular month.")
#sns.countplot(x='month', data=df, order=month_order)
#plt.show()

#month_mean = pd.DataFrame(df[df['revenue'] > 1e8].groupby('month')['revenue'].mean())
#month_mean['mon'] = month_mean.index
#plt.figure(figsize=(12,6))
#plt.title("Average Gross by the Month for Blockbuster Movies")
#sns.barplot(x='mon', y='revenue', data=month_mean, order=month_order)
#plt.show()

#fig, ax = plt.subplots(nrows=1, ncols=1,figsize=(15, 8))
#sns.boxplot(x='month', y='return', data=df[df['return'].notnull()], palette="muted", ax =ax, order=month_order)
#ax.set_ylim([0, 12])
#plt.show()

#plt.figure(figsize=(10,5))
#plt.title("Number of Movies released on a particular day.")
#sns.countplot(x='day', data=df, order=day_order)
#plt.show()

#year_count = df.groupby('year')['title'].count()
#plt.figure(figsize=(18,5))
#year_count.plot()
#plt.show()

# Earliest Movies Represented:-

print(df[df['year'] != 'NaT'][['title', 'year']].sort_values('year').head(10))

#months = {'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6, 'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12}

#df_21 = df.copy()
#df_21['year'] = df_21[df_21['year'] != 'NaT']['year'].astype(int)
#df_21 = df_21[df_21['year'] >=2000]
#hmap_21 = pd.pivot_table(data=df_21, index='month', columns='year', aggfunc='count', values='title')
#hmap_21 = hmap_21.fillna(0)

#sns.set(font_scale=1)
#f, ax = plt.subplots(figsize=(16, 8))
#sns.heatmap(hmap_21, annot=True, linewidths=.5, ax=ax, fmt='n', yticklabels=month_order)
#plt.show()

#sns.set(font_scale=1.25)

print(df['status'].value_counts())

# Spoken Languages

df['spoken_languages'] = df['spoken_languages'].fillna('[]').apply(ast.literal_eval).apply(lambda x: len(x) if isinstance(x, list) else np.nan)
print(df['spoken_languages'].value_counts())

print(df[df['spoken_languages'] >= 10][['title', 'year', 'spoken_languages']].sort_values('spoken_languages', ascending=False))

#sns.jointplot(x="spoken_languages", y="return", data=df, stat_func=stats.spearmanr, color="m")
#plt.show()

#Runtime:-
print(df['runtime'].describe())

#df['runtime'] = df['runtime'].astype('float')
#plt.figure(figsize=(12,6))
#sns.distplot(df[(df['runtime'] < 300) & (df['runtime'] > 0)]['runtime'])
#plt.show()

#df_mat = df[(df['return'].notnull()) & (df['runtime'] > 0) & (df['return'] < 10)]
#sns.jointplot('return', 'runtime', data=df_mat)
#plt.show()

#df_mat = df[(df['budget'].notnull()) & (df['runtime'] > 0)]
#sns.jointplot('budget', 'runtime', data=df_mat)
#plt.show()

#plt.figure(figsize=(18,5))
#year_runtime = df[df['year'] != 'NaT'].groupby('year')['runtime'].mean()
#plt.plot(year_runtime.index, year_runtime)
#plt.xticks(np.arange(1874, 2024, 10.0))
#plt.show()

print(df[df['runtime'] > 0][['runtime', 'title', 'year']].sort_values('runtime').head(10))

print(df[df['runtime'] > 0][['runtime', 'title', 'year']].sort_values('runtime', ascending=False).head(10))

#Budget:-

print(df['budget'].describe())

#sns.distplot(df[df['budget'].notnull()]['budget'])
#plt.show()

#df['budget'].plot(logy=True, kind='hist')
#plt.show()

# Most Expensive Movies of all Time:-
print(df[df['budget'].notnull()][['title', 'budget', 'revenue', 'return', 'year']].sort_values('budget', ascending=False).head(10))

#sns.jointplot(x='budget',y='revenue',data=df[df['return'].notnull()])
#plt.show()

#Revenue:-
print(df['revenue'].describe())

#sns.distplot(df[df['revenue'].notnull()]['revenue'])
#plt.show()

gross_top = df[['poster_path', 'title', 'budget', 'revenue', 'year']].sort_values('revenue', ascending=False).head(10)
print(gross_top)
#pd.set_option('display.max_colwidth', 100)
#HTML(gross_top.to_html(escape=False))

#pd.set_option('display.max_colwidth', 50)

#plt.figure(figsize=(18,5))
#year_revenue = df[(df['revenue'].notnull()) & (df['year'] != 'NaT')].groupby('year')['revenue'].max()
#plt.plot(year_revenue.index, year_revenue)
#plt.xticks(np.arange(1874, 2024, 10.0))
#plt.show()

#Most successful movies:-
print(df[(df['return'].notnull()) & (df['budget'] > 5e6)][['title', 'budget', 'revenue', 'return', 'year']].sort_values('return', ascending=False).head(10))

# Worst Box Office Disasters
print(df[(df['return'].notnull()) & (df['budget'] > 5e6) & (df['revenue'] > 10000)][['title', 'budget', 'revenue', 'return', 'year']].sort_values('return').head(10))

# Correlation matrix :-
#df['year'] = df['year'].replace('NaT', np.nan)

#df['year'] = df['year'].apply(clean_numeric)

#sns.set(font_scale=1)
#corr = df.corr()
#mask = np.zeros_like(corr)
#mask[np.triu_indices_from(mask)] = True
#with sns.axes_style("white"):
#    plt.figure(figsize=(9,9))
#    ax = sns.heatmap(corr, mask=mask, vmax=.3, square=True, annot=True)
#plt.show()

sns.set(font_scale=1.25)

# Genres:-

df['genres'] = df['genres'].fillna('[]').apply(ast.literal_eval).apply(lambda x: [i['name'] for i in x] if isinstance(x, list) else [])

s = df.apply(lambda x: pd.Series(x['genres']),axis=1).stack().reset_index(level=1, drop=True)
s.name = 'genre'

gen_df = df.drop('genres', axis=1).join(s)

print(gen_df['genre'].value_counts().shape[0])

pop_gen = pd.DataFrame(gen_df['genre'].value_counts()).reset_index()
pop_gen.columns = ['genre', 'movies']
print(pop_gen.head(10))


#sns.set(font_scale=0.8)
#plt.figure(figsize=(18,8))
#sns.barplot(x='genre', y='movies', data=pop_gen.head(15))
#plt.show()

#genres = ['Drama', 'Comedy', 'Thriller', 'Romance', 'Action', 'Horror', 'Crime', 'Adventure', 'Science Fiction', 'Mystery', 'Fantasy', 'Mystery', 'Animation']
#pop_gen_movies = gen_df[(gen_df['genre'].isin(genres)) & (gen_df['year'] >= 2000) & (gen_df['year'] <= 2017)]
#ctab = pd.crosstab([pop_gen_movies['year']], pop_gen_movies['genre']).apply(lambda x: x/x.sum(), axis=1)
#ctab[genres].plot(kind='bar', stacked=True, colormap='jet', figsize=(12,8)).legend(loc='center left', bbox_to_anchor=(1, 0.5))
#plt.title("Stacked Bar Chart of Movie Proportions by Genre")
#plt.show()

#ctab[genres].plot(kind='line', stacked=False, colormap='jet', figsize=(12,8)).legend(loc='center left', bbox_to_anchor=(1, 0.5))
#plt.show()

violin_genres = ['Drama', 'Comedy', 'Thriller', 'Romance', 'Action', 'Horror', 'Crime', 'Science Fiction', 'Fantasy', 'Animation']
violin_movies = gen_df[(gen_df['genre'].isin(violin_genres))]

#plt.figure(figsize=(18,8))
#fig, ax = plt.subplots(nrows=1, ncols=1,figsize=(15, 8))
#sns.boxplot(x='genre', y='revenue', data=violin_movies, palette="muted", ax =ax)
#ax.set_ylim([0, 3e8])
#plt.show()

#plt.figure(figsize=(18,8))
#fig, ax = plt.subplots(nrows=1, ncols=1,figsize=(15, 8))
#sns.boxplot(x='genre', y='return', data=violin_movies, palette="muted", ax =ax)
#ax.set_ylim([0, 10])
#plt.show()

credits_df = pd.read_csv('C:/MSc/Project/input/credits.csv')
print(credits_df.head())

def convert_int(x):
    try:
        return int(x)
    except:
        return np.nan

df['id'] = df['id'].apply(convert_int)

print(df[df['id'].isnull()])

df = df.drop([19730, 29503, 35587])
df['id'] = df['id'].astype('int')
df = df.merge(credits_df, on='id')
print(df.shape)