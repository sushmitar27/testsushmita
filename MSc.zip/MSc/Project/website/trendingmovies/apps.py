from django.apps import AppConfig


class TrendingmoviesConfig(AppConfig):
    name = 'trendingmovies'
