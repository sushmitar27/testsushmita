from django.apps import AppConfig


class VisualizationsConfig(AppConfig):
    name = 'visualizations'
