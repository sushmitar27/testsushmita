from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
import django
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
import io

import json
import datetime
import ast
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from scipy import stats
from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier, XGBRegressor
from wordcloud import WordCloud, STOPWORDS
import plotly
import plotly.offline as py
import plotly.graph_objs as go
import plotly.tools as tls
import warnings
warnings.filterwarnings('ignore')

def barchartview(request):
    fig = Figure()
    canvas = FigureCanvas(fig)

    sns.set_style('whitegrid')
    sns.set(font_scale=1.25)
    pd.set_option('display.max_colwidth', 50)

    df = pd.read_csv('C:/MSc/Project/input/movies_metadata.csv')

    df = df.drop(['imdb_id'], axis=1)

    print(df[df['original_title'] != df['title']][['title', 'original_title']].head())

    df = df.drop('original_title', axis=1)

    print(df[df['revenue'] == 0].shape)

    df['revenue'] = df['revenue'].replace(0, np.nan)

    df['budget'] = pd.to_numeric(df['budget'], errors='coerce')
    df['budget'] = df['budget'].replace(0, np.nan)
    print(df[df['budget'].isnull()].shape)

    df['return'] = df['revenue'] / df['budget']
    print(df[df['return'].isnull()].shape)

    df['year'] = pd.to_datetime(df['release_date'], errors='coerce').apply(lambda x: str(x).split('-')[0] if x != np.nan else np.nan)
    print(df['adult'].value_counts())

    df = df.drop('adult', axis=1)

    base_poster_url = 'http://image.tmdb.org/t/p/w185/'
    df['poster_path'] = "<img src='" + base_poster_url + df['poster_path'] + "' style='height:100px;'>"

    #Title and Overview Wordcloud

    df['title'] = df['title'].astype('str')
    df['overview'] = df['overview'].astype('str')

    title_corpus = ' '.join(df['title'])
    overview_corpus = ' '.join(df['overview'])

    title_wordcloud = WordCloud(stopwords=STOPWORDS, background_color='white', height=2000, width=4000).generate(title_corpus)
    plt.figure(figsize=(16,8))
    plt.imshow(title_wordcloud)
    plt.axis('off')
#    plt.show()

    overview_wordcloud = WordCloud(stopwords=STOPWORDS, background_color='white', height=2000, width=4000).generate(overview_corpus)
    plt.figure(figsize=(16,8))
    plt.imshow(overview_wordcloud)
    plt.axis('off')
    # plt.show()

    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    plt.close(fig)

    plt.savefig('/Users/SUSHMITA/Desktop/books_read.png', transparent=True, bbox_inches='tight')
    response = HttpResponse(buf.getvalue(), content_type='image/png')
    return response
